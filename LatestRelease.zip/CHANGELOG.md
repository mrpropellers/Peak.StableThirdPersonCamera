0.0.2
* Documentation updated (sort of)

0.0.1
* Adapted from StableCamera with basic third person camera logic added